﻿namespace WebApplication3.Models
{
    public class Offer
    {
        public int Quantity { get; set; }
        public decimal OfferPrice { get; set; }
    }
}
